DROP DATABASE IF EXISTS PetCare;
CREATE DATABASE PetCare;
USE PetCare;

SET NAMES utf8;
set character_set_client = utf8mb4;

CREATE TABLE Owner(
	ownerID INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(45) NOT NULL,
    username VARCHAR(45) NOT NULL,
    password VARCHAR(45) NOT NULL,
    email VARCHAR(45) NOT NULL,
    phoneNUM INT DEFAULT NULL,
    PRIMARY KEY (ownerID),
    UNIQUE KEY (username),
    UNIQUE KEY (password),
    UNIQUE KEY (email)
);

CREATE TABLE Groomer
(
	groomerID INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(45) NOT NULL,
    username VARCHAR(45) NOT NULL,
    password VARCHAR(45) NOT NULL,
    email VARCHAR(45) NOT NULL,
    phoneNUM INT DEFAULT NULL,
    PRIMARY KEY (groomerID),
    UNIQUE KEY (username),
    UNIQUE KEY (password),
    UNIQUE KEY (email)
);

CREATE TABLE Pet(
	petID INT NOT NULL AUTO_INCREMENT,
    ownerID INT,
    name VARCHAR(45),
    breed VARCHAR(45),
    notes LONGTEXT,
    image BLOB,
    PRIMARY KEY (petID),
    FOREIGN KEY (ownerID) REFERENCES Owner(ownerID)
);

CREATE TABLE GroomingAppointment(
	groomerID INT,
    petID INT,
    ownerID INT,
    date DATE,
    location VARCHAR(50),
    notes LONGTEXT,
    image BLOB,
    FOREIGN KEY (groomerID) REFERENCES Groomer(groomerID),
    FOREIGN KEY (petID) REFERENCES Pet(petID),
    FOREIGN KEY (ownerID) REFERENCES Owner(ownerID)
);

CREATE TABLE Inbox
(
	inboxID INT,
    PRIMARY KEY (inboxID)
);

ALTER TABLE Owner
	ADD inboxID INT,
    ADD FOREIGN KEY (inboxID) REFERENCES Inbox(inboxID);
    
ALTER TABLE Groomer
	ADD inboxID INT,
    ADD FOREIGN KEY (inboxID) REFERENCES Inbox(inboxID);


CREATE TABLE Message(
	messageID INT,
    inboxID INT,
    post longtext,
    PRIMARY KEY (messageID),
    FOREIGN KEY (inboxID) REFERENCES Inbox(inboxID)
);


